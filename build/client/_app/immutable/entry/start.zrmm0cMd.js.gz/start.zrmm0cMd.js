import{b as a}from"../chunks/entry.BtI8Upk3.js";export{a as start};
